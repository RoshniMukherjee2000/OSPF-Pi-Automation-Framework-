from src.connection import execute_command

out, err = execute_command("hostname")

print("STDOUT:")
print(out)

print("STDERR:")
print(err)
