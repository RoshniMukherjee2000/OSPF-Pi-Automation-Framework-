import os
import paramiko
import yaml

"""
connection.py
---------------
Reusable SSH utility module.

- Reads config from config/*.yaml
- Provides helper functions to execute commands on Linux DUT
- NO command execution at import time
"""

# ------------------------------------------------------------------
# Resolve project base directory
# ------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ------------------------------------------------------------------
# Load WLAN (server) configuration
# ------------------------------------------------------------------
WLAN_CLIENT_CONFIG = os.path.join(BASE_DIR, "config", "wlan_config_client.yaml")

with open(WLAN_CLIENT_CONFIG, "r") as f:
    wlan_cfg = yaml.safe_load(f)

SERVER_IP = wlan_cfg["server"]["ip"]
USERNAME  = wlan_cfg["server"]["user"]
PASSWORD  = wlan_cfg["server"]["password"]

# ------------------------------------------------------------------
# Load Bluetooth configuration (optional)
# ------------------------------------------------------------------
BT_DEVICE_CONFIG = os.path.join(BASE_DIR, "config", "BT_device_config.yaml")

BT_IP = None
BT_USER = None
BT_PASSWORD = None

if os.path.exists(BT_DEVICE_CONFIG):
    with open(BT_DEVICE_CONFIG, "r") as f:
        bt_cfg = yaml.safe_load(f)

    BT_IP = bt_cfg["client"]["ip"]
    BT_USER = bt_cfg["client"]["user"]
    BT_PASSWORD = bt_cfg["client"]["password"]


# ------------------------------------------------------------------
# SSH helper functions
# ------------------------------------------------------------------
def _ssh_connect(host, user, password):
    """
    Internal helper to create an SSH connection.
    """
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    ssh.connect(
        hostname=host,
        username=user,
        password=password,
        look_for_keys=False,
        allow_agent=False,
        timeout=10,
        banner_timeout=10,
        auth_timeout=10,
    )
    return ssh


def execute_command(cmd):
    """
    Execute a command on the Linux DUT (WLAN server).

    Returns:
        (stdout, stderr)
    """
    ssh = _ssh_connect(SERVER_IP, USERNAME, PASSWORD)

    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()

    ssh.close()
    return out, err


def execute_command_bt(cmd):
    """
    Execute a command on the Bluetooth DUT (if configured).
    """
    if not BT_IP:
        raise RuntimeError("Bluetooth device config not found")

    ssh = _ssh_connect(BT_IP, BT_USER, BT_PASSWORD)

    stdin, stdout, stderr = ssh.exec_command(cmd)
    out = stdout.read().decode().strip()
    err = stderr.read().decode().strip()

    ssh.close()
    return out, err
