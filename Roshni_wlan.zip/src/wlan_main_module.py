import os
import re
import logging
import yaml
from src.connection import execute_command

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ------------------------------------------------------------------
# Resolve base directory
# ------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

WLAN_CLIENT_CONFIG = os.path.join(BASE_DIR, "config", "wlan_config_client.yaml")
WLAN_SERVER_CONFIG = os.path.join(BASE_DIR, "config", "wlan_config_server.yaml")


def load_wifi_config():
    with open(WLAN_CLIENT_CONFIG, "r") as f:
        return yaml.safe_load(f)


def load_server_config():
    with open(WLAN_SERVER_CONFIG, "r") as f:
        return yaml.safe_load(f)


class WLAN:
    """Wi-Fi automation utilities"""

    # --------------------------------------------------------------
    # Wi-Fi throughput (iperf3)
    # --------------------------------------------------------------
    @staticmethod
    def client_server_module():
        wifi_cfg = load_wifi_config()
        wifi_ip = wifi_cfg["wifi"]["ip"].strip()

        result = execute_command(
            f"iperf3 -R -c {wifi_ip} -t 5 -i 1 -p 5203"
        )

        matches = re.findall(r"(\d+\.\d+)\s+Gbits/sec", str(result))

        if len(matches) >= 2:
            return (float(matches[-2]), float(matches[-1])), result

        logger.error("Unable to parse throughput")
        return (None, None), result

    # --------------------------------------------------------------
    # Connectivity check (FIXED)
    # --------------------------------------------------------------
    @staticmethod
    def check_ip():
        server_cfg = load_server_config()

        # YAML structure:
        # client:
        #   ip: "10.x.x.x"
        ip = server_cfg["client"]["ip"].strip()

        ping = execute_command(f"ping -c 5 {ip}")

        match = re.search(
            r'(\d+) packets transmitted, (\d+) received, (\d+)% packet loss',
            str(ping)
        )

        return float(match.group(3)) if match else -1

    # --------------------------------------------------------------
    # Wi-Fi connect
    # --------------------------------------------------------------
    @staticmethod
    def connect_to_wifi():
        wifi_cfg = load_wifi_config()
        ssid = wifi_cfg["wifi"]["ssid"].strip()
        password = wifi_cfg["wifi"].get("password", "")

        return execute_command(
            f"nmcli device wifi connect {ssid} password {password}"
        )

    # --------------------------------------------------------------
    # Check connected SSID
    # --------------------------------------------------------------
    @staticmethod
    def is_connected():
        actual = execute_command("iwgetid -r")[0].strip()
        return actual

    # --------------------------------------------------------------
    # Verify SSID from config
    # --------------------------------------------------------------
    @staticmethod
    def verify_ssid():
        return load_wifi_config()["wifi"]["ssid"].strip()

    # --------------------------------------------------------------
    # Verify active security
    # --------------------------------------------------------------
    @staticmethod
    def verify_security():
        wifi_cfg = load_wifi_config()
        ssid = wifi_cfg["wifi"]["ssid"].strip()

        sec_output = execute_command(
            "nmcli -f active,ssid,security dev wifi"
        )[0]

        for line in sec_output.splitlines():
            if line.startswith("yes") and ssid in line:
                return [m.lower() for m in line.split()[-1].split(",")]

        return []

    # --------------------------------------------------------------
    # Verify configured security modes
    # --------------------------------------------------------------
    @staticmethod
    def verify_security_config():
        return [
            m.lower()
            for m in load_wifi_config()["wifi"].get("security_modes", [])
        ]
    @staticmethod
    def start_iperf_server():
        """
        Start iperf3 server in background on DUT.
        """
        execute_command(
            "nohup iperf3 -s -p 5203 > /tmp/iperf.log 2>&1 &"
        )

    @staticmethod
    def stop_iperf_server():
        """
        Stop iperf3 server to free the port.
        """
        execute_command("pkill iperf3")

