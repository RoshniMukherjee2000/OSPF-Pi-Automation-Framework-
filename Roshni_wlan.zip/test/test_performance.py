# 

import time
import logging

logger = logging.getLogger(__name__)


def test_wifi_throughput(setup):
    """
    Automated WLAN throughput test using iperf3.
    Validates successful execution and measurement.
    """

    # Start iperf3 server (non-blocking)
    setup.start_iperf_server()
    time.sleep(2)  # allow server to initialize

    # Run iperf3 client
    (sender, receiver), output = setup.client_server_module()

    # Stop iperf3 server
    setup.stop_iperf_server()

    logger.info(f"Sender throughput: {sender}")
    logger.info(f"Receiver throughput: {receiver}")

    # Assertions (safe & defensible)
    assert sender is not None, "Sender throughput not captured"
    assert receiver is not None, "Receiver throughput not captured"
    assert sender > 0, "Invalid sender throughput value"
    assert receiver > 0, "Invalid receiver throughput value"
